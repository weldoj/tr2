import http.server
import socketserver
import json
import time
from threading import Lock

# --- "Banco de Dados" simples em memória ---
dados_coletados = []
dados_lock = Lock()
PORT = 8000

class MeuHandler(http.server.BaseHTTPRequestHandler):

    def _send_response(self, status_code, content_type, body):
        self.send_response(status_code)
        self.send_header('Content-type', content_type)
        self.end_headers()
        self.wfile.write(body.encode('utf-8'))

    def do_GET(self):
        """ Lida com requisições GET """
        if self.path == '/':
            # Gera o HTML do Dashboard dinamicamente
            html_body = "<html><head><title>Dashboard Ambiental</title>"
            # Adiciona auto-refresh a cada 10 segundos
            html_body += "<meta http-equiv='refresh' content='10'>"
            html_body += "</head><body>"
            html_body += "<h1>Monitoramento Ambiental - Salas de Equipamentos</h1>"
            html_body += "<h2>Dados Coletados (Mais recente primeiro):</h2>"
            html_body += "<table border='1'><tr><th>Timestamp</th><th>ID Sensor</th><th>Temp.</th><th>Umidade</th><th>Poeira</th></tr>"

            # Pega os dados de forma segura e exibe os últimos 10
            with dados_lock:
                # Invertemos a lista para mostrar os mais novos primeiro
                for item in reversed(dados_coletados[-10:]):
                    ts = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(item['timestamp']))
                    html_body += f"<tr><td>{ts}</td>"
                    html_body += f"<td>{item['sensor_id']}</td>"
                    html_body += f"<td>{item['data'].get('temperatura', 'N/A')} °C</td>"
                    html_body += f"<td>{item['data'].get('umidade', 'N/A')} %</td>"
                    html_body += f"<td>{item['data'].get('poeira', 'N/A')} µg/m³</td></tr>"
            
            html_body += "</table></body></html>"
            self._send_response(200, 'text/html', html_body)
        
        elif self.path == '/api/json':
            # Rota opcional para ver os dados brutos
            with dados_lock:
                json_data = json.dumps(dados_coletados[-10:])
            self._send_response(200, 'application/json', json_data)
            
        else:
            self._send_response(404, 'text/plain', 'Pagina nao encontrada')

    def do_POST(self):
        """ Lida com requisições POST """
        if self.path == '/api/data':
            try:
                # tamanho do conteúdo
                content_length = int(self.headers['Content-Length'])
                
                # corpo da requisição
                post_data_bytes = self.rfile.read(content_length)
                
                # Converte o corpo (bytes) para string e depois para JSON
                post_data_str = post_data_bytes.decode('utf-8')
                payload = json.loads(post_data_str)

                # Adiciona um timestamp do servidor 
                payload['timestamp_servidor'] = int(time.time())
                
                # Armazena os dados
                with dados_lock:
                    dados_coletados.append(payload)
                
                print(f"[SERVIDOR] Dado recebido e armazenado: {payload}")
                
                # Responde ao cliente que deu tudo certo
                self._send_response(200, 'application/json', '{"status": "ok"}')

            except Exception as e:
                print(f"[SERVIDOR] Erro ao processar POST: {e}")
                self._send_response(400, 'text/plain', f'Erro: {e}')
        else:
            self._send_response(404, 'text/plain', 'Rota POST nao encontrada')

# Inicia o servidor 
with socketserver.TCPServer(("", PORT), MeuHandler) as httpd:
    print(f"Servidor iniciado na porta {PORT}")
    print(f"Acesse o dashboard em: http://localhost:{PORT}")
    httpd.serve_forever()